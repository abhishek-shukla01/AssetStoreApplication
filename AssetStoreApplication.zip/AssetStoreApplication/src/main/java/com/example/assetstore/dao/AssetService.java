package com.example.assetstore.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assetstore.exception.DataFormatException;
import com.example.assetstore.exception.NotFoundException;
import com.example.assetstore.model.AssetDetails;
import com.example.assetstore.model.StoreDetails;
import com.example.assetstore.repository.AssetRepository;
import com.example.assetstore.repository.StoreRepository;

@Service
public class AssetService {
	@Autowired
	AssetRepository assetrep;

	@Autowired
	StoreRepository storerep;

	@Autowired
	AssetDetails assetdetails;

	public AssetDetails addAssetDetails(AssetDetails as) {
		Date date = new Date();
		as.setCreateddate(date);
		as.setModifieddate(date);
		AssetDetails asset = assetrep.save(as);
		System.out.println("saving Data" + asset);
		return asset;

	}

	public List<AssetDetails> getAllAsset() {
		List<AssetDetails> assets = assetrep.findAll();
		System.out.println("Getting Data" + assets);
		return assets;

	}

	public Optional<AssetDetails> getAssetById(long id) {
		if (assetrep.findById(id).isEmpty()) {
			throw new DataFormatException("ID is not available");
		}
		return (assetrep.findById(id));

	}

// public AssetDetails updateAssetStore(AssetDetails as){
// AssetDetails asd = assetrep.getById(as.getId());
// asd.setAssetname(as.getAssetname());
// asd.setStoredetails(as.getStoredetails());
// Date date=new Date();
// asd.setModifieddate(date);
// AssetDetails asset=assetrep.save(asd);
// return asset;
//
// }
	public AssetDetails updateAssetStore(AssetDetails as) {
		if (assetrep.findById(as.getId()).isEmpty()) {
			throw new NotFoundException("Not Exists");

		}
		AssetDetails asd = assetrep.getById(as.getId());
		asd.setAssetname(as.getAssetname());
		asd.setStoredetails(as.getStoredetails());
		Date date = new Date();
		asd.setModifieddate(date);
		AssetDetails asset = assetrep.save(asd);
		return asset;

	}

	public void deleteAsset(long id) {
		if (assetrep.findById(id).isEmpty()) {
			throw new NotFoundException("Not Exists");
		}
		assetrep.deleteById(id);
	}

}