package com.example.assetstore.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.assetstore.dao.AssetService;
import com.example.assetstore.model.AssetDetails;
import com.example.assetstore.model.StoreDetails;

@RestController
@RequestMapping("/api")
public class AssetController {
	@Autowired
	AssetDetails asset;

	@Autowired
	AssetService assetserv;
	
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
	@GetMapping("/asset")
	public List<AssetDetails> getAllAsset() {
		return assetserv.getAllAsset();
	}
    
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping("/assets")
	public AssetDetails addAsset(@RequestBody AssetDetails asset) {
		return assetserv.addAssetDetails(asset);
		
	}
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
	@GetMapping("/asset/{id}")
	public Optional<AssetDetails> getAsset(@PathVariable(value = "id") long id) {
		Optional<AssetDetails> as = assetserv.getAssetById(id);
		System.out.println(as);
		return as;
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PutMapping("/asset/{id}")
	public AssetDetails updateAssetStore(@PathVariable(value = "id") long id, @RequestBody AssetDetails asset) {
		asset.setId(id);
		return assetserv.updateAssetStore(asset);
	}
	
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@DeleteMapping("/asset/{id}")
	public void deleteAsset(@PathVariable(value = "id") long id) {
		assetserv.deleteAsset(id);
		
	}
}
