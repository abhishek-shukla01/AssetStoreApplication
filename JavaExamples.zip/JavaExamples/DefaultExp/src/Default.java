public class Default implements MyInterface {
		   public static void main(String args[]) {
		      Default obj = new Default();
		      obj.display();
		   }
		}