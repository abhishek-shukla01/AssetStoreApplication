package javaprojects;

import java.util.ArrayList;  
import java.util.Collections;  
import java.util.List;  
class Product{  
    int unit;  
    String name;  
    float price;  
    public Product(int unit, String name, float price) {  
        super();  
        this.unit = unit;  
        this.name = name;  
        this.price = price;  
    }  
}  