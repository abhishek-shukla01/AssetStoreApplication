package javaprojects;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

  
public class Lambdaexp{  
    public static void main(String[] args) {  
        List<Product> list=new ArrayList<Product>();  
          
        //Adding Products  
        list.add(new Product(5,"Maggiee",100f));  
        list.add(new Product(2,"Cake",300f));  
        list.add(new Product(6,"Chocholate",120f));  
          
        System.out.println("Sorting on the basis of name...");  
  
        // implementing lambda expression  
        Collections.sort(list,(p1,p2)->{  
        return p1.name.compareTo(p2.name);  
        });  
        for(Product p:list){  
            System.out.println(p.unit+" "+p.name+" "+p.price);  
        }  
  
    }  
}  