import java.util.concurrent.TimeUnit;

class Threadimpl implements Runnable {  
  
      public void run() {  
           
         try {  
            Long num = (long) (Math.random() / 30);  
            System.out.println("Thread Name: " +Thread.currentThread().getName());  
               TimeUnit.SECONDS.sleep(num);  
            System.out.println("after sleep Thread Name: " +Thread.currentThread().getName());  
         } catch (InterruptedException e) {  
            e.printStackTrace();  
         }  
      }  
   }  